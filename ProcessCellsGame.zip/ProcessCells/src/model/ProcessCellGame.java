package model;

import java.awt.Color;
import java.util.Random;

/**
 * This class extends GameModel and implements the logic of strategy #1.
 * A description of this strategy can be found in the javadoc for the
 * processCell method.
 * 
 * We define an empty cell as BoardCell.EMPTY. An empty row is defined 
 * as one where every cell corresponds to BoardCell.EMPTY.
 * 
 * @author Department of Computer Science, UMCP
 */

/* Group Members 
1. Musa Waseem - mwaseem1
2. Sai Thanneeru - sthanne1
3. Soumil Girdhar - sgirdhar 
 */

public class ProcessCellGame extends Game {
	private int strategy;
	private int score;
	private Random random;
	private boolean emptyRow = true;


	/**
	 * Defines a board with empty cells. It relies on the super class
	 * constructor to define the board.  The random parameter is used
	 * for the generation of random cells.  The strategy parameter
	 * defines which processing cell strategy to use (for this project
	 * the default will be 1).
	 * 
	 * @param maxRows
	 * @param maxCols
	 * @param random
	 * @param strategy
	 */
	public ProcessCellGame(int maxRows, int maxCols, Random random, int strategy) {
		super(maxRows, maxCols);
		this.strategy = strategy;
		this.random = random;
		for (int i = 0; i < getMaxRows(); i++) {
			for (int j = 0; j < getMaxCols(); j++) {
				board[i][j] = BoardCell.EMPTY;
			}
		}

	}

	/**
	 * The game is over when the last board row (row with index board.length -1)
	 * is different from empty row.
	 */
	public boolean isGameOver() {
		for (int i = 0; i < getMaxCols(); i++) {
			if (board[getMaxRows() - 1][i] != BoardCell.EMPTY) {
				return true;
			}
		}
		return false;
	}

	public int getScore() {
		return score;
	}

	/**
	 * This method will attempt to insert a row of random BoardCell objects if
	 * the last board row (row with index board.length -1) corresponds to the
	 * empty row; otherwise no operation will take place.
	 */
	public void nextAnimationStep() {
		for (int i = 0; i < getMaxCols(); i++) {
			if (board[getMaxRows() - 1][i] != BoardCell.EMPTY) {
				return;
			}
		}
		if (emptyRow) {
			for (int i = getMaxRows() - 1; i > 0; i--) {
				for (int j = 0; j < getMaxCols(); j++) {
					board[i][j] = board[i - 1][j];
				}
			}
			for (int i = 0; i < getMaxCols(); i++) {
				board[0][i] = BoardCell.getNonEmptyRandomBoardCell(random);
			}
		}
	}

	/**
	 * The default processing associated with this method is that for
	 * strategy #1. If you add a new strategy, make sure you add
	 * a conditional so the processing described below is associated with
	 * strategy #1.
	 * <br><br>
	 * Strategy #1 Description.<br><br>
	 * This method will turn to BoardCell.EMPTY the cell selected and any
	 * adjacent surrounding cells in the vertical, horizontal, and diagonal
	 * directions that have the same color. The clearing of adjacent cells
	 * will continue as long as cells have a color that corresponds to the 
	 * selected cell. Notice that the clearing process does not clear every 
	 * single cell that surrounds a cell selected (only those found in the 
	 * vertical, horizontal or diagonal directions).
	 * <br>
	 * IMPORTANT: Clearing a cell adds one point to the game's score.<br>
	 * <br>
	 * 
	 * If after processing cells, any rows in the board are empty,those
	 * rows will collapse, moving non-empty rows upward. For example, if 
	 * we have the following board (an * represents an empty cell):<br />
	 * <br />
	 * RRR<br />
	 * GGG<br />
	 * YYY<br />
	 * * * *<br/>
	 * <br />
	 * then processing each cell of the second row will generate the following
	 * board<br />
	 * <br />
	 * RRR<br />
	 * YYY<br />
	 * * * *<br/>
	 * * * *<br/>
	 * <br />
	 * IMPORTANT: If the game has ended no action will take place.
	 * 
	 * 
	 */
	public void processCell(int rowIndex, int colIndex) {
		if (this.strategy == 1) {
			if (board[rowIndex][colIndex] != BoardCell.EMPTY) {
				Color color = board[rowIndex][colIndex].getColor();
				board[rowIndex][colIndex] = BoardCell.EMPTY;
				score++;
				// Process cells above the selected cell
				for (int i = rowIndex-1; i >= 0; i--) {
					if (board[i][colIndex].getColor() == color) {
						board[i][colIndex] = BoardCell.EMPTY;
						score++;
					} else {
						// Stop processing cells in this direction
						break; 
					}
				}

				// Process cells below the selected cell
				for (int i = rowIndex+1; i < getMaxRows(); i++) {
					if (board[i][colIndex].getColor() == color) {
						board[i][colIndex] = BoardCell.EMPTY;
						score++;
					} else {
						break; 
					}
				}

				// Process cells to the left of the selected cell
				for (int j = colIndex-1; j >= 0; j--) {
					if (board[rowIndex][j].getColor() == color) {
						board[rowIndex][j] = BoardCell.EMPTY;
						score++;
					} else {
						break; 
					}
				}

				// Process cells to the right of the selected cell
				for (int j = colIndex + 1; j < getMaxCols(); j++) {
					if (board[rowIndex][j].getColor() == color) {
						board[rowIndex][j] = BoardCell.EMPTY;
						score++;
					} else {
						break; 
					}
				}
				// process cells in the upper left diagonal
				for (int i = rowIndex - 1, j = colIndex - 1; i >= 0 && j >= 0; i--, j--) {
					if (board[i][j].getColor() == color) {
						board[i][j] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}

				}

				// process cells in the upper right diagonal direction
				for (int i = rowIndex - 1, j = colIndex + 1; i >= 0 
						&& j < getMaxCols(); i--, j++) {
					if (board[i][j].getColor() == color) {
						board[i][j] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}

				}

				// process cells in the lower left diagonal direction
				for (int i = rowIndex + 1, j = colIndex - 1; i < getMaxRows() 
						&& j >= 0; i++, j--) {
					if (board[i][j].getColor() == color) {
						board[i][j] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}

				}

				// process cells in the lower right diagonal direction
				for (int i = rowIndex, j = colIndex + 1; i < getMaxRows() 
						&& j < getMaxCols(); i++, j++) {
					if (board[i][j].getColor() == color) {
						board[i][j] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}

				}

				for (int j = colIndex + 1; j < getMaxCols(); j++) {
					if (board[rowIndex][j].getColor() == color) {
						board[rowIndex][j] = BoardCell.EMPTY;
						score++;
					} else {
						break; 
					}
				}

				// collapse empty rows
				for (int i = 0; i < getMaxRows(); i++) {
					boolean isEmptyRow = true;
					for (int j = 0; j < getMaxCols(); j++) {
						if (board[i][j] != BoardCell.EMPTY) {
							isEmptyRow = false;
							break;
						}
					}
					if (isEmptyRow) {
						for (int j = i; j < getMaxRows()-1; j++) {
							for (int k = 0; k < getMaxCols(); k++) {
								board[j][k] = board[j+1][k];
							}
						}
						for (int j = 0; j < getMaxCols(); j++) {
							board[getMaxRows()-1][j] = BoardCell.EMPTY;
						}
					}
				}
			}
		} else if (this.strategy == 2) {
			if (board[rowIndex][colIndex] != BoardCell.EMPTY) {
				if (board[rowIndex][colIndex] == BoardCell.YELLOW) {
					board[rowIndex][colIndex] = BoardCell.EMPTY;
					score++;
				} else {
					board[rowIndex][colIndex] = BoardCell.YELLOW;
				}
			}
		}

	}
}